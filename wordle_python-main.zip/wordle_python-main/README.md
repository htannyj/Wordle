# wordle_python

https://www.youtube.com/watch?v=9M1oDT_JLJk
